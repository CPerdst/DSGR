/* Compatible <termio.h> for old `struct termio' ioctl interface.
   This is obsolete; use the POSIX.1 `struct termios' interface
   defined in <termios.h> instead.  */

#include <termios.h>
#include <sys/ioctl.h>
